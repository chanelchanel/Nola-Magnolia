# NOLA Magnolias — Capstone Project

## 🏀 Overview
NOLA Magnolias is a fictional WNBA-inspired team based in New Orleans, designed to embody empowerment, style, and storytelling through interactive web design.

This capstone project includes multiple themed web pages, dynamic JavaScript components, responsive styling, and a strong brand identity. 

## 🌸 Features
- Dynamic game schedule with countdown timer
- Interactive player bios and team values explorer
- Community-focused storytelling on the About page
- Embedded contact form with validation
- Gradient button styling for brand consistency
- Fully responsive layout for mobile and desktop

## 📁 File Structure





